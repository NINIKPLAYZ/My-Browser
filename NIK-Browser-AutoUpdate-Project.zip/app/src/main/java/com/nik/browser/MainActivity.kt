package com.nik.browser

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.app.DownloadManager
import android.net.Uri
import android.os.Environment
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private lateinit var address: EditText
    private var incognito = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        loadHome()
        checkForUpdate()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(8, 8, 8, 4)
            gravity = Gravity.CENTER_VERTICAL
        }

        val back = Button(this).apply {
            text = "‹"
            setOnClickListener { if (::web.isInitialized && web.canGoBack()) web.goBack() }
        }

        address = EditText(this).apply {
            hint = "Search"
            singleLine = true
            setPadding(16, 0, 16, 0)
            setOnEditorActionListener { _, _, _ ->
                openInput(text.toString())
                true
            }
        }

        val go = Button(this).apply {
            text = "Go"
            setOnClickListener { openInput(address.text.toString()) }
        }

        top.addView(back, LinearLayout.LayoutParams(48, 48))
        top.addView(address, LinearLayout.LayoutParams(0, 48, 1f))
        top.addView(go, LinearLayout.LayoutParams(64, 48))
        root.addView(top)

        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.cacheMode = WebSettings.LOAD_DEFAULT
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
        }
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(4, 2, 4, 2)
        }

        fun btn(label: String, action: () -> Unit): Button =
            Button(this).apply {
                text = label
                setOnClickListener { action() }
                minHeight = 40
                minimumHeight = 40
            }

        bottom.addView(btn("Home") { loadHome() },
            LinearLayout.LayoutParams(0, 48, 1f))
        bottom.addView(btn("Tabs") { Toast.makeText(this, "Tabs: 1", Toast.LENGTH_SHORT).show() },
            LinearLayout.LayoutParams(0, 48, 1f))
        bottom.addView(btn("Menu") { showMenu() },
            LinearLayout.LayoutParams(0, 48, 1f))

        root.addView(bottom)
        setContentView(root)
    }

    private fun loadHome() {
        address.setText("")
        web.loadUrl("https://www.google.com")
    }

    private fun openInput(value: String) {
        val q = value.trim()
        if (q.isEmpty()) return
        val url = if (q.startsWith("http://") || q.startsWith("https://")) q
        else "https://www.google.com/search?q=" + java.net.URLEncoder.encode(q, "UTF-8")
        web.loadUrl(url)
    }


    private fun checkForUpdate() {
        Thread {
            try {
                val url = java.net.URL("https://raw.githubusercontent.com/NINIKPLAYZ/NIK-Browser/main/version.json")
                val json = url.readText()
                val obj = org.json.JSONObject(json)
                val latestCode = obj.getInt("versionCode")
                val latestName = obj.getString("versionName")
                val force = obj.optBoolean("forceUpdate", false)
                val apkUrl = obj.getString("apkUrl")
                val currentCode = BuildConfig.VERSION_CODE

                if (latestCode > currentCode) {
                    runOnUiThread {
                        val dialog = AlertDialog.Builder(this)
                            .setTitle("Update Available")
                            .setMessage("NIK Browser $latestName is available.")
                            .setPositiveButton("Update") { _, _ ->
                                val request = DownloadManager.Request(Uri.parse(apkUrl))
                                    .setTitle("NIK Browser $latestName")
                                    .setDescription("Downloading update...")
                                    .setNotificationVisibility(
                                        DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED
                                    )
                                    .setDestinationInExternalPublicDir(
                                        Environment.DIRECTORY_DOWNLOADS,
                                        "NIK-Browser-$latestName.apk"
                                    )
                                    .setMimeType("application/vnd.android.package-archive")
                                val dm = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
                                dm.enqueue(request)
                                Toast.makeText(this, "Update download started", Toast.LENGTH_SHORT).show()
                            }
                            .setNegativeButton(if (force) "Exit" else "Later") { _, _ ->
                                if (force) finish()
                            }
                            .setCancelable(!force)
                            .create()
                        dialog.show()
                    }
                }
            } catch (_: Exception) {
                // Update check failures do not block normal browsing.
            }
        }.start()
    }

    private fun showMenu() {
        val items = arrayOf(
            "Incognito Mode", "History", "Cookies", "DNS",
            "Ad Blocker", "Downloads", "Theme", "Settings", "About NIK Browser"
        )
        AlertDialog.Builder(this)
            .setTitle("NIK Browser")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> {
                        incognito = !incognito
                        Toast.makeText(this, if (incognito) "Incognito ON" else "Incognito OFF", Toast.LENGTH_SHORT).show()
                    }
                    1 -> web.loadUrl("https://www.google.com/search?q=browser+history")
                    2 -> Toast.makeText(this, "Cookies management", Toast.LENGTH_SHORT).show()
                    3 -> Toast.makeText(this, "DNS settings", Toast.LENGTH_SHORT).show()
                    4 -> Toast.makeText(this, "Ad Blocker settings", Toast.LENGTH_SHORT).show()
                    5 -> Toast.makeText(this, "Downloads", Toast.LENGTH_SHORT).show()
                    6 -> Toast.makeText(this, "Theme: System / Light / Dark", Toast.LENGTH_SHORT).show()
                    7 -> Toast.makeText(this, "Settings", Toast.LENGTH_SHORT).show()
                    8 -> Toast.makeText(this, "NIK Browser 1.0.0", Toast.LENGTH_SHORT).show()
                }
            }
            .show()
    }
}
